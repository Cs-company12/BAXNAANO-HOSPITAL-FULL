const express = require('express');
const { authenticate, authorize } = require('../middleware/auth');
const db = require('../config/database');
const router = express.Router();

router.get('/', authenticate, (req, res) => {
  const { search, category, low_stock } = req.query;
  let sql = `SELECT * FROM inventory WHERE 1=1`;
  const params = [];
  if (search) { sql += ` AND item_name LIKE ?`; params.push(`%${search}%`); }
  if (category) { sql += ` AND category = ?`; params.push(category); }
  if (low_stock === '1') { sql += ` AND qty <= reorder_level`; }
  sql += ` ORDER BY item_name`;
  res.json(db.prepare(sql).all(...params));
});

router.post('/', authenticate, authorize(['pharmacy','admin']), (req, res) => {
  const { item_name, category, qty, unit_price, reorder_level, supplier } = req.body;
  if (!item_name) return res.status(400).json({ error: 'Item name required' });
  const result = db.prepare(`
    INSERT INTO inventory (item_name, category, qty, unit_price, reorder_level, supplier)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(item_name, category, qty || 0, unit_price || 0, reorder_level || 10, supplier);
  res.status(201).json({ id: result.lastInsertRowid });
});

router.put('/:id', authenticate, authorize(['pharmacy','admin']), (req, res) => {
  const { item_name, category, qty, unit_price, reorder_level, supplier } = req.body;
  db.prepare('UPDATE inventory SET item_name=?, category=?, qty=?, unit_price=?, reorder_level=?, supplier=? WHERE id=?')
    .run(item_name, category, qty, unit_price, reorder_level, supplier, req.params.id);
  res.json({ message: 'Updated' });
});

router.delete('/:id', authenticate, authorize(['admin']), (req, res) => {
  db.prepare('DELETE FROM inventory WHERE id = ?').run(req.params.id);
  res.json({ message: 'Deleted' });
});

module.exports = router;
