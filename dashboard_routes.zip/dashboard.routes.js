const express = require('express');
const { authenticate, authorize } = require('../middleware/auth');
const db = require('../config/database');
const router = express.Router();

router.get('/dashboard', authenticate, (req, res) => {
  const today = new Date().toISOString().split('T')[0];
  res.json({
    today_appointments: db.prepare(`SELECT COUNT(*) as c FROM appointments WHERE DATE(appt_date) = ?`).get(today).c,
    waiting_patients: db.prepare(`SELECT COUNT(*) as c FROM appointments WHERE status = 'Waiting'`).get().c,
    today_sales: db.prepare(`SELECT COALESCE(SUM(amount), 0) as total FROM payments WHERE DATE(created_at) = ?`).get(today).total,
    low_stock: db.prepare(`SELECT COUNT(*) as c FROM inventory WHERE qty <= reorder_level`).get().c,
    today_lab: db.prepare(`SELECT COUNT(*) as c FROM lab_requests WHERE DATE(created_at) = ?`).get(today).c,
    pending_rx: db.prepare(`SELECT COUNT(*) as c FROM prescriptions WHERE status = 'Quotation'`).get().c,
    total_patients: db.prepare(`SELECT COUNT(*) as c FROM patients`).get().c,
    total_doctors: db.prepare(`SELECT COUNT(*) as c FROM doctors WHERE active = 1`).get().c
  });
});

router.get('/revenue', authenticate, authorize(['admin','cashier']), (req, res) => {
  const { period = 'daily' } = req.query;
  let sql = '';
  if (period === 'daily') {
    sql = `SELECT DATE(created_at) as label, SUM(amount) as value FROM payments GROUP BY DATE(created_at) ORDER BY label DESC LIMIT 30`;
  } else if (period === 'monthly') {
    sql = `SELECT strftime('%Y-%m', created_at) as label, SUM(amount) as value FROM payments GROUP BY strftime('%Y-%m', created_at) ORDER BY label DESC LIMIT 12`;
  } else {
    sql = `SELECT DATE(created_at) as label, SUM(amount) as value FROM payments GROUP BY DATE(created_at) ORDER BY label DESC LIMIT 7`;
  }
  res.json(db.prepare(sql).all());
});

router.get('/appointments-by-doctor', authenticate, (req, res) => {
  const sql = `SELECT doctor_name as label, COUNT(*) as value FROM appointments GROUP BY doctor_name ORDER BY value DESC LIMIT 10`;
  res.json(db.prepare(sql).all());
});

module.exports = router;
