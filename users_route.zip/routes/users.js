const express = require('express');
const bcrypt = require('bcryptjs');
const { authenticate, authorize } = require('../middleware/auth');
const db = require('../config/database');
const router = express.Router();

router.get('/', authenticate, authorize(['admin']), (req, res) => {
  res.json(db.prepare('SELECT id, email, role, full_name, branch, active, created_at FROM users').all());
});

router.post('/', authenticate, authorize(['admin']), (req, res) => {
  const { email, password, role, full_name, branch } = req.body;
  if (!email || !password || !role) return res.status(400).json({ error: 'Missing fields' });
  const hash = bcrypt.hashSync(password, 12);
  const result = db.prepare('INSERT INTO users (email, password_hash, role, full_name, branch) VALUES (?, ?, ?, ?, ?)')
    .run(email, hash, role, full_name, branch || 'HQ');
  res.status(201).json({ id: result.lastInsertRowid });
});

router.put('/:id', authenticate, authorize(['admin']), (req, res) => {
  const { role, full_name, branch, active } = req.body;
  db.prepare('UPDATE users SET role = ?, full_name = ?, branch = ?, active = ? WHERE id = ?')
    .run(role, full_name, branch, active ? 1 : 0, req.params.id);
  res.json({ message: 'Updated' });
});

router.put('/:id/password', authenticate, authorize(['admin']), (req, res) => {
  const { password } = req.body;
  const hash = bcrypt.hashSync(password, 12);
  db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hash, req.params.id);
  res.json({ message: 'Password updated' });
});

module.exports = router;
