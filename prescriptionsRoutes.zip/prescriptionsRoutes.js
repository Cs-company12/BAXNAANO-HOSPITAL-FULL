const express = require('express');
const { authenticate, authorize } = require('../middleware/auth');
const db = require('../config/database');
const router = express.Router();

router.get('/', authenticate, (req, res) => {
  const { search, status } = req.query;
  let sql = `
    SELECT pr.*, p.full_name as patient, p.patient_id as pid
    FROM prescriptions pr
    JOIN patients p ON pr.patient_id = p.id
    WHERE 1=1
  `;
  const params = [];
  if (search) {
    sql += ` AND (p.full_name LIKE ? OR pr.rx_num LIKE ?)`;
    params.push(`%${search}%`, `%${search}%`);
  }
  if (status) { sql += ` AND pr.status = ?`; params.push(status); }
  sql += ` ORDER BY pr.created_at DESC`;
  res.json(db.prepare(sql).all(...params));
});

router.get('/:id/items', authenticate, (req, res) => {
  const items = db.prepare('SELECT * FROM prescription_items WHERE prescription_id = ?').all(req.params.id);
  res.json(items);
});

router.post('/', authenticate, authorize(['pharmacy','doctor','admin']), (req, res) => {
  const { patient_name, patient_id, sex, age, mobile, doctor, items } = req.body;
  if (!patient_name) return res.status(400).json({ error: 'Patient name required' });

  let patient = patient_id ? db.prepare('SELECT * FROM patients WHERE patient_id = ?').get(patient_id) : null;
  if (!patient) {
    const pid = patient_id || `P${Date.now()}`;
    const r = db.prepare('INSERT INTO patients (patient_id, full_name, sex, age, mobile) VALUES (?, ?, ?, ?, ?)')
      .run(pid, patient_name, sex, age, mobile);
    patient = { id: r.lastInsertRowid };
  }

  const total = (items || []).reduce((s, it) => s + ((it.qty || 0) * (it.unit_price || 0)), 0);
  const count = db.prepare('SELECT COUNT(*) as c FROM prescriptions').get().c;
  const rxNum = 'S' + (84660 + count);

  const result = db.prepare(`
    INSERT INTO prescriptions (rx_num, patient_id, doctor_name, status, total, discount)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(rxNum, patient.id, doctor, 'Quotation', total, 0);

  const presId = result.lastInsertRowid;
  const stmt = db.prepare(`
    INSERT INTO prescription_items (prescription_id, brand_name, dosage_form, route, frequency, dose, qty, available_qty, unit_price, subtotal)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  (items || []).forEach(it => {
    const sub = (it.qty || 0) * (it.unit_price || 0);
    stmt.run(presId, it.brand_name, it.dosage_form, it.route, it.frequency, it.dose, it.qty, it.available_qty || 0, it.unit_price || 0, sub);
  });

  const rx = db.prepare(`
    SELECT pr.*, p.full_name as patient, p.patient_id as pid
    FROM prescriptions pr JOIN patients p ON pr.patient_id = p.id WHERE pr.id = ?
  `).get(presId);
  res.status(201).json(rx);
});

router.put('/:id/dispense', authenticate, authorize(['pharmacy','admin']), (req, res) => {
  db.prepare('UPDATE prescriptions SET status = ? WHERE id = ? OR rx_num = ?').run('Done', req.params.id, req.params.id);
  res.json({ message: 'Dispensed' });
});

router.delete('/:id', authenticate, authorize(['pharmacy','admin']), (req, res) => {
  db.prepare('DELETE FROM prescriptions WHERE id = ? OR rx_num = ?').run(req.params.id, req.params.id);
  res.json({ message: 'Deleted' });
});

module.exports = router;
