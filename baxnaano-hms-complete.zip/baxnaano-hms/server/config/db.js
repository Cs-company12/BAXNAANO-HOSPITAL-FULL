const Database = require('better-sqlite3');
const path = require('path');
const bcrypt = require('bcryptjs');

const dbPath = path.join(__dirname, '../../database/baxnaano.db');
const db = new Database(dbPath);

db.exec(`
  PRAGMA foreign_keys = ON;

  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('admin','cashier','lab','pharmacy','doctor','reception')),
    full_name TEXT NOT NULL,
    branch TEXT DEFAULT 'HQ',
    active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

function seed() {
  const count = db.prepare('SELECT COUNT(*) as c FROM users').get().c;
  if (count > 0) return;

  const hash = bcrypt.hashSync('hospital2024', 12);

  const userStmt = db.prepare(
    'INSERT INTO users (email, password_hash, role, full_name, branch) VALUES (?, ?, ?, ?, ?)'
  );

  userStmt.run('admin@baxnaano.so', hash, 'admin', 'System Admin', 'HQ');
}

seed();

module.exports = db;
