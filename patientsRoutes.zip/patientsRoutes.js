const express = require('express');
const { authenticate } = require('../middleware/auth');
const db = require('../config/database');
const router = express.Router();

router.get('/', authenticate, (req, res) => {
  const { search } = req.query;
  let sql = `SELECT * FROM patients WHERE 1=1`;
  const params = [];
  if (search) {
    sql += ` AND (full_name LIKE ? OR patient_id LIKE ? OR mobile LIKE ?)`;
    params.push(`%${search}%`, `%${search}%`, `%${search}%`);
  }
  sql += ` ORDER BY created_at DESC`;
  res.json(db.prepare(sql).all(...params));
});

router.post('/', authenticate, (req, res) => {
  const { patient_id, full_name, sex, age, mobile, address, blood_type, allergies } = req.body;
  if (!full_name) return res.status(400).json({ error: 'Patient name required' });
  const pid = patient_id || `P${Date.now()}`;
  const result = db.prepare(`
    INSERT INTO patients (patient_id, full_name, sex, age, mobile, address, blood_type, allergies)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(pid, full_name, sex, age, mobile, address, blood_type, allergies);
  res.status(201).json({ id: result.lastInsertRowid, patient_id: pid, full_name });
});

router.get('/:id', authenticate, (req, res) => {
  const patient = db.prepare('SELECT * FROM patients WHERE id = ? OR patient_id = ?').get(req.params.id, req.params.id);
  if (!patient) return res.status(404).json({ error: 'Patient not found' });
  res.json(patient);
});

router.put('/:id', authenticate, (req, res) => {
  const { full_name, sex, age, mobile, address, blood_type, allergies } = req.body;
  db.prepare('UPDATE patients SET full_name=?, sex=?, age=?, mobile=?, address=?, blood_type=?, allergies=? WHERE id=? OR patient_id=?')
    .run(full_name, sex, age, mobile, address, blood_type, allergies, req.params.id, req.params.id);
  res.json({ message: 'Patient updated' });
});

module.exports = router;
