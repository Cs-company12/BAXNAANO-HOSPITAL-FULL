const express = require('express');
const { authenticate, authorize } = require('../middleware/auth');
const db = require('../config/database');
const router = express.Router();

router.get('/payments', authenticate, (req, res) => {
  const { date_from, date_to, search } = req.query;
  let sql = `
    SELECT pay.*, p.full_name as patient, a.appointment_num
    FROM payments pay
    JOIN patients p ON pay.patient_id = p.id
    LEFT JOIN appointments a ON pay.appointment_id = a.id
    WHERE 1=1
  `;
  const params = [];
  if (search) { sql += ` AND (p.full_name LIKE ? OR pay.receipt_num LIKE ?)`; params.push(`%${search}%`, `%${search}%`); }
  if (date_from) { sql += ` AND DATE(pay.created_at) >= ?`; params.push(date_from); }
  if (date_to) { sql += ` AND DATE(pay.created_at) <= ?`; params.push(date_to); }
  sql += ` ORDER BY pay.created_at DESC`;
  res.json(db.prepare(sql).all(...params));
});

router.post('/pay', authenticate, authorize(['cashier','admin']), (req, res) => {
  const { appointment_id, patient_id, amount, payment_method } = req.body;
  if (!amount || amount <= 0) return res.status(400).json({ error: 'Invalid amount' });
  const count = db.prepare('SELECT COUNT(*) as c FROM payments').get().c;
  const receiptNum = `RCP${100000 + count}`;
  const result = db.prepare(`
    INSERT INTO payments (receipt_num, appointment_id, patient_id, amount, payment_method, created_by)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(receiptNum, appointment_id || null, patient_id, amount, payment_method || 'Cash', req.user.id);
  res.status(201).json({ id: result.lastInsertRowid, receipt_num: receiptNum });
});

module.exports = router;
