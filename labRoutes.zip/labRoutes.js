const express = require('express');
const { authenticate, authorize } = require('../middleware/auth');
const db = require('../config/database');
const router = express.Router();

router.get('/', authenticate, (req, res) => {
  const { search, status } = req.query;
  let sql = `
    SELECT l.*, p.full_name as patient, p.patient_id as pid, p.sex, p.age, p.mobile
    FROM lab_requests l
    JOIN patients p ON l.patient_id = p.id
    WHERE 1=1
  `;
  const params = [];
  if (search) {
    sql += ` AND (p.full_name LIKE ? OR l.test_num LIKE ?)`;
    params.push(`%${search}%`, `%${search}%`);
  }
  if (status) { sql += ` AND l.status = ?`; params.push(status); }
  sql += ` ORDER BY l.created_at DESC`;
  res.json(db.prepare(sql).all(...params));
});

router.post('/', authenticate, authorize(['lab','doctor','admin','cashier']), (req, res) => {
  const { patient_name, patient_id, sex, age, mobile, tests } = req.body;
  if (!patient_name) return res.status(400).json({ error: 'Patient name required' });

  let patient = patient_id ? db.prepare('SELECT * FROM patients WHERE patient_id = ?').get(patient_id) : null;
  if (!patient) {
    const pid = patient_id || `P${Date.now()}`;
    const r = db.prepare('INSERT INTO patients (patient_id, full_name, sex, age, mobile) VALUES (?, ?, ?, ?, ?)')
      .run(pid, patient_name, sex, age, mobile);
    patient = { id: r.lastInsertRowid };
  }

  const total = (tests || []).reduce((s, t) => s + (t.price || 0), 0);
  const count = db.prepare('SELECT COUNT(*) as c FROM lab_requests').get().c;
  const testNum = String(27420 + count);

  const result = db.prepare(`
    INSERT INTO lab_requests (test_num, patient_id, tests_json, total_price, status)
    VALUES (?, ?, ?, ?, ?)
  `).run(testNum, patient.id, JSON.stringify(tests || []), total, 'Waiting');

  const lab = db.prepare(`
    SELECT l.*, p.full_name as patient, p.patient_id as pid, p.sex, p.age, p.mobile
    FROM lab_requests l JOIN patients p ON l.patient_id = p.id WHERE l.id = ?
  `).get(result.lastInsertRowid);

  res.status(201).json(lab);
});

router.put('/:id/collect', authenticate, authorize(['lab','admin']), (req, res) => {
  db.prepare('UPDATE lab_requests SET status = ?, collected_by = ? WHERE id = ? OR test_num = ?')
    .run('Partially Collected', req.user.id, req.params.id, req.params.id);
  res.json({ message: 'Sample collected' });
});

router.put('/:id/complete', authenticate, authorize(['lab','admin']), (req, res) => {
  db.prepare('UPDATE lab_requests SET status = ? WHERE id = ? OR test_num = ?')
    .run('Completed', req.params.id, req.params.id);
  res.json({ message: 'Completed' });
});

router.delete('/:id', authenticate, authorize(['lab','admin']), (req, res) => {
  db.prepare('DELETE FROM lab_requests WHERE id = ? OR test_num = ?').run(req.params.id, req.params.id);
  res.json({ message: 'Deleted' });
});

module.exports = router;
