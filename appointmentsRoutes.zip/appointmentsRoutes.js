const express = require('express');
const { authenticate, authorize } = require('../middleware/auth');
const db = require('../config/database');
const router = express.Router();

router.get('/', authenticate, (req, res) => {
  const { search, status, doctor, date_from, date_to, page = 1, limit = 50 } = req.query;
  let sql = `
    SELECT a.*, p.patient_id as pid, p.full_name as patient, p.sex, p.age, p.mobile
    FROM appointments a
    JOIN patients p ON a.patient_id = p.id
    WHERE 1=1
  `;
  const params = [];
  if (search) {
    sql += ` AND (p.full_name LIKE ? OR a.appointment_num LIKE ? OR p.patient_id LIKE ?)`;
    params.push(`%${search}%`, `%${search}%`, `%${search}%`);
  }
  if (status) { sql += ` AND a.status = ?`; params.push(status); }
  if (doctor) { sql += ` AND a.doctor_name LIKE ?`; params.push(`%${doctor}%`); }
  if (date_from) { sql += ` AND DATE(a.appt_date) >= ?`; params.push(date_from); }
  if (date_to) { sql += ` AND DATE(a.appt_date) <= ?`; params.push(date_to); }
  sql += ` ORDER BY a.appt_date DESC LIMIT ? OFFSET ?`;
  params.push(Number(limit), (Number(page) - 1) * Number(limit));
  res.json(db.prepare(sql).all(...params));
});

router.post('/', authenticate, authorize(['cashier','reception','admin','doctor']), (req, res) => {
  const { patient_name, patient_id, sex, age, mobile, doctor, payment_type, slot, branch, appt_type } = req.body;
  if (!patient_name) return res.status(400).json({ error: 'Patient name required' });

  let patient = patient_id ? db.prepare('SELECT * FROM patients WHERE patient_id = ?').get(patient_id) : null;
  if (!patient) {
    const pid = patient_id || `P${Date.now()}`;
    const r = db.prepare('INSERT INTO patients (patient_id, full_name, sex, age, mobile) VALUES (?, ?, ?, ?, ?)')
      .run(pid, patient_name, sex, age, mobile);
    patient = { id: r.lastInsertRowid, patient_id: pid };
  }

  const count = db.prepare('SELECT COUNT(*) as c FROM appointments').get().c;
  const apptNum = `AP0${42315 + count}`;
  const today = new Date().toISOString().split('T')[0];
  const maxQ = db.prepare(`SELECT COALESCE(MAX(queue_num),0) as mq FROM appointments WHERE DATE(appt_date) = ?`).get(today).mq;

  const result = db.prepare(`
    INSERT INTO appointments (appointment_num, patient_id, doctor_name, branch, slot, type, appt_type, payment_type, status, queue_num, created_by, appt_date, in_date)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
  `).run(apptNum, patient.id, doctor, branch || 'HQ', slot || 'Day', 'OPD', appt_type || 'New', payment_type || 'Cash', 'Waiting', maxQ + 1, req.user.id);

  const appt = db.prepare(`
    SELECT a.*, p.full_name as patient, p.patient_id as pid, p.sex, p.age, p.mobile
    FROM appointments a JOIN patients p ON a.patient_id = p.id WHERE a.id = ?
  `).get(result.lastInsertRowid);

  res.status(201).json(appt);
});

router.get('/:id', authenticate, (req, res) => {
  const appt = db.prepare(`
    SELECT a.*, p.full_name as patient, p.patient_id as pid, p.sex, p.age, p.mobile
    FROM appointments a JOIN patients p ON a.patient_id = p.id
    WHERE a.id = ? OR a.appointment_num = ?
  `).get(req.params.id, req.params.id);
  if (!appt) return res.status(404).json({ error: 'Not found' });
  res.json(appt);
});

router.put('/:id/status', authenticate, (req, res) => {
  const { status } = req.body;
  db.prepare('UPDATE appointments SET status = ? WHERE id = ? OR appointment_num = ?').run(status, req.params.id, req.params.id);
  res.json({ message: 'Status updated' });
});

router.delete('/:id', authenticate, authorize(['admin','cashier']), (req, res) => {
  db.prepare('DELETE FROM appointments WHERE id = ? OR appointment_num = ?').run(req.params.id, req.params.id);
  res.json({ message: 'Deleted' });
});

module.exports = router;
